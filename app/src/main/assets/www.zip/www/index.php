<!DOCTYPE html>
<?php echo "test"; ?>
<html lang="en">
    
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title>Heart Gate - index</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/jquery.mobile-1.4.5.min.css">
        <link rel="stylesheet" href="css/style.css">
        
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.mobile-1.4.5.min.js"></script>
		<script src="js/TweenMax.min.js"></script>
    </head>
    
    <body>

		<div data-role="page" class="master" id="pageLogin">
			<img src="img/bg_index_portrait.jpg" width="100%" style="position:absolute; z-index:0">
			<img src="img/icon_HG_Name.png" width="70%" style="margin-top:100px; position: relative; left: 15%" />
			<div id="gate">
				<div class="handArrow">
					<img src="img/hand-o-up.svg" style="width: 30%; position: absolute; z-index: 999999; left: 35%; top: 35%;">
					<p style="color: #fff; position:absolute; z-index: 9999999; width: 100%; text-align: center">click any where...</p>
				</div>
				<img src="img/icon_open_gate_top.png" width="100%" style="position: fixed; top:0px; z-index:99999" id="topGate">
				<img src="img/icon_open_gate_bottom.png" width="100%" style="position: fixed; bottom:0; z-index:99999" id="botGate">
			</div>
			<div data-role="header">
				<img src="img/icon_M_top_right.png" width="190" style="top:0; right:0; position:fixed;" />
			</div>
			
			<div role="main" class="ui-content" style="background-color: rgba(55, 147, 237, 0.5); position: relative; border-radius: 50%;">
				<div class="clearfix"></div><br>
				<form class="form-horizontal" id="login-form">
					<div class="form-group">
						<div class="col-sm-10">
							<input type="text" class="form-control" id="username" placeholder="Username" style="background:none; border-bottom: 1px solid #fff !important; border: none; text-align: center; color: #fff !important;">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-10">
							<input type="password" class="form-control" id="password" placeholder="Password" autocomplete="off" style="background:none; border-bottom: 1px solid #fff !important; border: none; text-align: center; color: #fff !important;">
						</div>
					</div>
					<div class="form-group">
						<div class="col-xs-12">
							<button type="submit" class="btn btn-default" id="loginBtn" style="width:100%; border-radius:15px; border: 1px solid #fff; background: none; color: #fff">Log in</button>
						</div>
					</div>
				</form>
				<div class="col-xs-12">
					<label style="cursor: pointer; color:#fff; text-align:center; width: 100%; padding: 5px" id="forgotpass">Forgot Password<br>or</label>
				</div>
				<form id="resetPass" style="display:none">
					<div class="form-group">
						<label>Password will be sent to </label>
						<input type="email" id="emailaddress" name="emailaddress" placeholder="your email" class="form-control">
					</div>
					<button type="submit" class="btn btn-primary pull-right col-xs-12" id="submitEmail">Submit</button>
				</form>
                
				<div class="clearfix"></div>
                <br>
				<div class="col-xs-12" style="margin-bottom:100px">
					<a href="register.html" type="button" class="btn btn-success btn-lg" style="width:100%; border-radius:15px; border: 1px solid #fff; background: none; color: #fff">Sign up</a>
                    <p style="color:#fff; text-align: center; margin-top: 10px; width: 100%; font-size: 10px">Developed by CAT<br>Creative Advertising Thinking</p>
				</div>
			</div>
			<img src="img/icon_concor_bottom_left.png" width="125" style="left:0; bottom:0px; position:fixed; opacity:1">
			<img src="img/icon_MERCK_bottom_right.png" width="125" style="right:0; bottom:0px; position:fixed; opacity:1">
			<p id="devcat" style="position: absolute; bottom: 55px; color:#fff; text-align: center; z-index: 99999999999999; width: 100%; font-size: 10px">Developed by CAT<br>Creative Advertising Thinking</p>
			
		</div>
    
		
     <!-- jQuery -->
        
		<script>
			$(function(){
                
//                'use strict';
                
                var x;
                
                function getCookie(name) {
                    var nameEQ = name + "=",
                        ca = document.cookie.split(';'),
                        i,
                        c;

                    for (i = 0; i < ca.length; i += 1) {
                        c = ca[i];
                        while (c.charAt(0) === ' ') {c = c.substring(1, c.length); }
                        if (c.indexOf(nameEQ) === 0) {
                            return c.substring(nameEQ.length, c.length);
                        }
                    }
                    return null;
                }
                
                x = getCookie('userid');
                                
                //console.log(x);
                
                if (x && x !== undefined && x !== null && x !== 'undefined') {
                    location.href = 'home.html';
                }

				
				
				$('input').focus(function () {
					$(this).attr('placeholder', '');
				});
				$('input').focusout(function () {
					$('#username').attr('placeholder', 'Username');
					$('#password').attr('placeholder', 'Password');
				});
				
				$('#gate').on('click', function () {
					TweenMax.to($('#topGate'), 5, {y: "-100%"});
					TweenMax.to($('#botGate'), 5, {y: "100%"});
					$('.handArrow').hide();
					$('#devcat').hide();
				});
				
				TweenMax.fromTo($('.handArrow img') , 1, {y: "15%"}, {y: "55%", repeat: -1, yoyo: true});
				
			});
			
		</script>

        <script src="js/manageUsers.js"></script>
        
    </body>
</html>
